package com.bm.android.chat.user_access.models

/* Used in checkFirestore to add a user document to collection users */
class User(var uid:String? = "", var email:String = "")
